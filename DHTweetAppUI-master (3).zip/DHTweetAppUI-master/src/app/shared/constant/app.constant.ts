export const AppConstant = {
    // Cookies Key
    cookieUserKey: 'userName'

}