export class TweetsReply {
    tweetReplyId?: string
    repliedBy?: string;
    tweetReplyBody?: string;
    datetime?: Date;
}