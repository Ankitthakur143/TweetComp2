export const environment = {
  production: true,
  // baseURL: '//'+location.hostname+":8080",
  baseURL: "//54.245.62.11:8080",
};
